package ext.aks4125.nasajetpack.presentation.ui.detail

import ext.aks4125.nasajetpack.data.local.PlanetEntity

data class DetailUiState(
    val item: PlanetEntity? = null,
)
